# Prompt para Codex -- Integrar scrapers de Supermercados en Pro_descuento

Copia y pega TODO lo que sigue como instruccion para Codex (con el repo
`red-blanca/Pro_descuento` montado y el contenido de este zip disponible).

---

Eres un ingeniero senior trabajando en el repo `red-blanca/Pro_descuento`
(rama `master`). Vas a integrar un paquete de scrapers de supermercados chilenos
que te entrego en la carpeta `supermercados/` (descomprimida del zip
`scrapers_supermercados.zip`). El objetivo es que queden disponibles en el
buscador, en una **pestana/seccion propia llamada "Supermercados"**, separada en
la VISTA pero usando la MISMA funcionalidad de busqueda del proyecto (no crear
un endpoint nuevo).

## Contexto del proyecto
- Backend Python: `global_search.py` (motor de busqueda multi-fuente con
  helpers `_source_payload`, `_filter_words`, `_limit_for`, `RUNNERS`,
  `build_config`, `_raw_category_str`, `has_category`) y `server.py` (FastAPI:
  `/api/global-search` con jobs async `_JOBS`, `/api/global-search/{job_id}`,
  `/api/global-categories`, `/api/health`).
- Cada scraper expone el contrato: `fetch_categories()`,
  `collect_results(query, limit, scan_scope, max_pages, **kwargs) -> (items, meta)`
  y `apply_filters(items, ...)`. Igual que `pcfactory` y `aliexpress`.
- Frontend: React + Vite en `web/`.

## Fuentes que agrega el paquete (7)
jumbo, santaisabel, unimarc, alvi (VTEX, listas) + lider, acuenta (Walmart) +
tottus (Falabella). Las 3 ultimas traen el arbol de categorias curado y el
endpoint JSON es configurable por variable de entorno (ver Paso 5).

## Tareas

### 1. Copiar carpetas al repo (raiz, junto a los otros *_scraper/)
- `vtex_scraper/`, `lider_scraper/`, `tottus_scraper/`, y `registry.py`.

### 2. Cablear `global_search.py`
Sigue `INTEGRACION.md` secciones 2.1 a 2.7:
- Agrega `vtex_scraper`, `lider_scraper`, `tottus_scraper` a `sys.path`.
- Importa: `jumbo, santaisabel, unimarc, alvi, lider, acuenta, tottus`.
- Crea un runner `_run_<source>(cfg)` por fuente (patron `_run_pcfactory`),
  pasando `<source>_category_id` como `category_id`.
- Registralos en `RUNNERS`.
- En `build_config`, lee `<source>_category_id` con `_raw_category_str` y
  `<source>_word`.
- Incluye las 7 fuentes en `has_category` (pueden correr sin palabra clave).

### 3. Cablear `server.py`
Sigue `INTEGRACION.md` seccion 3:
- Replica el bloque sys.path + imports try/except.
- Agrega los 7 campos `<source>_category_id: str = ""` al `GlobalSearchPayload`.
- En `/api/global-categories`, agrega el bloque try/except por tienda que
  llama a `fetch_categories()`.

### 4. Crear la pestana "Supermercados" en el front (web/)
Sigue `INTEGRACION.md` seccion 4 (4.1 a 4.3):
- Agrega una pestana/tab nueva "Supermercados" en la navegacion principal,
  con el MISMO look & feel que las vistas existentes.
- Usa `web_supermercados/SupermercadosPanel.jsx` como base: copialo a
  `web/src/components/` y montalo en esa pestana. Adapta clases/estilos a los
  del proyecto y, si existe una tarjeta de resultados (ResultCard), usala en
  vez de la tarjeta minima del componente.
- IMPORTANTE: NO mezcles estas 7 fuentes en los checkboxes del buscador global
  existente. Van SOLO dentro de la pestana de Supermercados (separacion de
  vista). La funcionalidad sigue siendo la misma: la pestana llama a
  `/api/global-search` y `/api/global-categories`, acotado a las sources de
  super.

### 5. Confirmar endpoints Walmart/Falabella (lider, acuenta, tottus)
- Las 4 VTEX (jumbo, santaisabel, unimarc, alvi) deberian funcionar directo.
- Para lider/acuenta/tottus: abre cada web, navega a una categoria, abre
  DevTools -> Network -> Fetch/XHR, copia la URL del JSON de productos y
  configura el template:
    - lider/acuenta: campo `api_template` en `lider_scraper/lider_stores.py` o
      variables `LIDER_API_TEMPLATE` / `ACUENTA_API_TEMPLATE`.
    - tottus: `TOTTUS_API_TEMPLATE` o `API_TEMPLATE_DEFAULT` en
      `tottus_scraper/tottus.py`.
  Campos del template: `{host} {category} {query} {limit} {page}`.
- Si el endpoint usa nombres de campo distintos, ajusta las tuplas `_*_KEYS`
  del parser. Si el sitio bloquea peticiones directas, replica el fallback con
  Playwright que ya usa el scraper de AliExpress.

## Pruebas que debes ejecutar y reportar
1. `python -m py_compile` sobre todos los .py nuevos y los modificados.
2. Prueba el motor aislado (sin levantar server):
   - `python demo_supermercados.py categorias --store jumbo` (debe listar cats).
   - `python demo_supermercados.py extraer --store jumbo --category <id> --limit 20`
     (debe traer productos reales en JSON con price/discount_percent).
   - Repite para unimarc, santaisabel, alvi.
3. Levanta `server.py` y verifica:
   - `GET /api/global-categories` devuelve categorias para las 7 fuentes.
   - `POST /api/global-search` con `sources:["jumbo"]` + `jumbo_category_id`
     devuelve resultados (directo o via job_id + polling).
4. Levanta el front (`web/`), entra a la pestana "Supermercados", selecciona
   Jumbo + una categoria y confirma que aparecen resultados con su tarjeta.
5. Reporta: que funciono, que endpoints de Walmart/Falabella confirmaste, y
   cualquier ajuste de `_*_KEYS` que hayas tenido que hacer.

## Reglas
- No rompas las fuentes existentes del proyecto.
- Manten el estilo de codigo y el contrato de las funciones.
- Si una de las 3 tiendas Walmart/Falabella no se puede confirmar, dejala
  registrada pero devolviendo `[]` con `meta["warning"]` (ya viene asi), sin
  romper el resto.
