# Scrapers de Supermercados por Categoria

Extraccion de productos de supermercados chilenos POR CATEGORIA (no por
producto puntual), con salida en el mismo formato JSON que ya usa el proyecto
(pcfactory, aliexpress, etc.).

## Tiendas incluidas

- jumbo       -> Jumbo        (VTEX)      API publica de catalogo VTEX
- santaisabel -> Santa Isabel (VTEX)      API publica de catalogo VTEX
- unimarc     -> Unimarc      (VTEX)      API publica de catalogo VTEX
- alvi        -> Alvi         (VTEX)      API publica de catalogo VTEX
- lider       -> Lider        (Walmart)   endpoint JSON configurable
- acuenta     -> acuenta      (Walmart)   endpoint JSON configurable
- tottus      -> Tottus       (Falabella) endpoint JSON configurable

Todas son cadenas presentes en Curico, Chile. Las 4 VTEX funcionan con la API
publica. Lider/acuenta/Tottus traen el arbol de categorias curado y quedan
listas para enchufar el endpoint JSON una vez confirmado (ver INTEGRACION.md).

## Estructura

    supermercados/
      vtex_scraper/
        vtex_core.py      motor generico VTEX (categorias + extraccion + filtros)
        stores.py         config de Jumbo, Santa Isabel, Unimarc, Alvi
        jumbo.py santaisabel.py unimarc.py alvi.py
      lider_scraper/
        lider_core.py     motor Walmart (arbol curado + parser flexible)
        lider_stores.py   config de Lider y acuenta
        lider.py acuenta.py
      tottus_scraper/
        tottus.py         scraper Falabella/Tottus
      registry.py         mapa source -> modulo
      demo_supermercados.py  CLI de prueba y exportacion JSON
      INTEGRACION.md      como enchufarlo a server.py / global_search.py / UI

## Contrato (igual que el resto de scrapers)

Cada modulo de tienda expone:

- fetch_categories() -> list[dict]  (id, value, label, name, depth, parent_id, has_children)
- collect_results(query="", limit=80, scan_scope="complete", max_pages=0, category_id="") -> (items, meta)
- apply_filters(items, min_price=0, max_price=0, word="", include_words=[], exclude_words=[], min_discount=0) -> items

## Esquema de cada producto (JSON)

    {
      "id": "jumbo#12345",
      "title": "Leche Entera 1L",
      "price": 990.0,
      "price_clp_final": 990.0,
      "formatted_price": "$ 990",
      "price_original": 1290.0,
      "normal_price": "$ 1.290",
      "discount_percent": 23,
      "url": "https://www.jumbo.cl/leche-entera-1l/p",
      "image": "https://.../leche.jpg",
      "store": "Jumbo",
      "brand": "Soprole",
      "category": "Lacteos / Leches",
      "source": "jumbo"
    }

Nota de precios: son supermercados nacionales en CLP, por lo que NO se aplican
impuestos de importacion (a diferencia de AliExpress). El discount_percent se
calcula solo entre precio normal y precio oferta.

## Uso rapido (CLI)

    cd supermercados
    python3 demo_supermercados.py categorias --store jumbo
    python3 demo_supermercados.py extraer --store jumbo --category 1000 --limit 60
    python3 demo_supermercados.py extraer --store unimarc,jumbo --category despensa --limit 40

Genera exports/super_..._/<tienda>.json, all_results.json y _summary.json,
igual que global_search.py.

## Notas tecnicas

- Solo libreria estandar de Python (urllib), sin dependencias nuevas.
- VTEX: maximo 50 productos por request; el motor pagina automaticamente
  (_from/_to) hasta alcanzar limit.
- Si una tienda usa precios/stock por zona (Curico), ajusta sales_channel en
  vtex_scraper/stores.py.
- Para Lider/acuenta/Tottus, ver INTEGRACION.md seccion 5 para confirmar el
  endpoint o activar el fallback Playwright (mismo patron que AliExpress).

## Importante

No fue posible probar las llamadas en vivo porque el entorno donde se generaron
estos archivos no tiene acceso a internet. La logica de normalizacion,
paginacion y filtros fue validada con datos de ejemplo. Al integrarlo, confirma
los endpoints reales de cada sitio (especialmente Lider/acuenta/Tottus)
navegando con DevTools -> Network.
