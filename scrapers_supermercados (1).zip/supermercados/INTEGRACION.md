# Integracion al buscador global (server.py + global_search.py + UI React)

Estos scrapers siguen el mismo contrato que el resto del proyecto
(fetch_categories, collect_results(query, limit, scan_scope, max_pages, **kwargs)
que devuelve (items, meta), y apply_filters(items, ...)), por lo que se integran
igual que pcfactory y aliexpress.

Fuentes que agrega este paquete:

- jumbo       -> Jumbo        (VTEX)      API publica VTEX (listo)
- santaisabel -> Santa Isabel (VTEX)      API publica VTEX (listo)
- unimarc     -> Unimarc      (VTEX)      API publica VTEX (listo)
- alvi        -> Alvi         (VTEX)      API publica VTEX (listo)
- lider       -> Lider        (Walmart)   endpoint configurable (confirmar Paso 1)
- acuenta     -> acuenta      (Walmart)   endpoint configurable (confirmar Paso 1)
- tottus      -> Tottus       (Falabella) endpoint configurable (confirmar Paso 1)

Las 4 tiendas VTEX usan la API publica de catalogo y deberian funcionar
directamente. Lider/acuenta/Tottus traen el arbol de categorias curado y quedan
listas para enchufar el endpoint JSON (variable de entorno) una vez confirmado,
sin tocar el resto del codigo.

--------------------------------------------------------------------------

## 1) Copiar carpetas al repo

Copia estas carpetas a la raiz del repo (junto a pcfactory_scraper/,
aliexpress_scraper/, etc.):

    vtex_scraper/
    lider_scraper/
    tottus_scraper/

--------------------------------------------------------------------------

## 2) global_search.py

### 2.1 Agregar los directorios a sys.path

Donde ya se agregan los otros scrapers a sys.path, agrega:

    for _sub in ("vtex_scraper", "lider_scraper", "tottus_scraper"):
        _path = ROOT / _sub
        if _path.is_dir():
            sys.path.insert(0, str(_path))

### 2.2 Importar los modulos

    import jumbo, santaisabel, unimarc, alvi  # vtex_scraper
    import lider, acuenta                      # lider_scraper
    import tottus                              # tottus_scraper

### 2.3 DEFAULT_SOURCES

    DEFAULT_SOURCES = [
        ..., "pcfactory", "aliexpress",
        "jumbo", "santaisabel", "unimarc", "alvi", "lider", "acuenta", "tottus",
    ]

### 2.4 Runners (_run_<source>)

Mismo patron que _run_pcfactory / _run_aliexpress. Cada uno toma la categoria
desde cfg y la pasa como category_id:

    def _run_jumbo(cfg):
        items, meta = jumbo.collect_results(
            query=cfg["query"],
            limit=_limit_for(cfg["scan_scope"], cfg.get("max_items"), fast_default=60),
            scan_scope=cfg["scan_scope"],
            category_id=cfg.get("jumbo_category_id", ""),
        )
        items = jumbo.apply_filters(
            items,
            min_price=cfg.get("min_price", 0),
            max_price=cfg.get("max_price", 0),
            word=cfg.get("jumbo_word", ""),
        )
        items = _filter_words(items, cfg)
        return _source_payload("jumbo", cfg["query"], items, meta)

Replica para santaisabel, unimarc, alvi, lider, acuenta, tottus (cambiando el
modulo y la clave <source>_category_id).

### 2.5 RUNNERS

    RUNNERS.update({
        "jumbo": _run_jumbo,
        "santaisabel": _run_santaisabel,
        "unimarc": _run_unimarc,
        "alvi": _run_alvi,
        "lider": _run_lider,
        "acuenta": _run_acuenta,
        "tottus": _run_tottus,
    })

### 2.6 build_config

En build_config(raw), lee la categoria por fuente (igual que
aliexpress_category_id). Usa _raw_category_str para preservar "" como "todas":

    for _src in ("jumbo", "santaisabel", "unimarc", "alvi", "lider", "acuenta", "tottus"):
        cfg[f"{_src}_category_id"] = _raw_category_str(raw.get(f"{_src}_category_id"))
        cfg[f"{_src}_word"] = (raw.get(f"{_src}_word") or "").strip()

### 2.7 has_category

Incluye estas fuentes en la verificacion has_category (pueden correr sin
palabra clave porque navegan por categoria):

    has_category = any([
        ...,
        cfg.get("jumbo_category_id"),
        cfg.get("santaisabel_category_id"),
        cfg.get("unimarc_category_id"),
        cfg.get("alvi_category_id"),
        cfg.get("lider_category_id"),
        cfg.get("acuenta_category_id"),
        cfg.get("tottus_category_id"),
    ])

--------------------------------------------------------------------------

## 3) server.py

### 3.1 sys.path + imports

Replica el bloque de sys.path y los imports try/except igual que en
global_search.py (puntos 2.1 y 2.2).

### 3.2 GlobalSearchPayload (pydantic)

Agrega los campos por fuente, igual que aliexpress_category_id:

    class GlobalSearchPayload(BaseModel):
        ...
        jumbo_category_id: str = ""
        santaisabel_category_id: str = ""
        unimarc_category_id: str = ""
        alvi_category_id: str = ""
        lider_category_id: str = ""
        acuenta_category_id: str = ""
        tottus_category_id: str = ""

### 3.3 /api/global-categories

En el endpoint que arma el diccionario categories por fuente, agrega un bloque
try/except por cada tienda (igual que pcfactory/aliexpress):

    for _name, _module in (("jumbo", jumbo), ("santaisabel", santaisabel),
                           ("unimarc", unimarc), ("alvi", alvi),
                           ("lider", lider), ("acuenta", acuenta), ("tottus", tottus)):
        try:
            categories[_name] = _module.fetch_categories()
        except Exception as exc:  # noqa: BLE001
            categories[_name] = []

--------------------------------------------------------------------------

## 4) UI React (web/) -- PESTANA "SUPERMERCADOS" (vista separada)

OBJETIVO: una vista SEPARADA (pestana / seccion propia), pero la MISMA
funcionalidad de busqueda por dentro. NO se crea un endpoint nuevo: la pestana
de Supermercados llama al mismo /api/global-search del proyecto, solo que
acotado a las 7 fuentes de supermercado y en modo "por categoria".

### 4.1 Estructura de navegacion (separar SOLO la vista)

1. Agrega una pestana/tab nueva al nivel de navegacion principal del proyecto
   (donde hoy se elige el buscador/seccion), etiquetada "Supermercados".
   Mantiene el mismo look & feel que las vistas existentes.
2. El contenido de esa pestana es el componente de referencia incluido en este
   paquete: web_supermercados/SupermercadosPanel.jsx. Copialo a la carpeta de
   componentes del front (p.ej. web/src/components/) y montalo cuando la
   pestana "Supermercados" este activa.
3. NO mezcles estas 7 fuentes en los checkboxes del buscador global existente:
   van SOLO dentro de la pestana de Supermercados (esa es la "separacion de
   vista"). El resto de fuentes del proyecto se queda como esta.

### 4.2 Funcionalidad (unificada, sin endpoint nuevo)

Dentro de la pestana, SupermercadosPanel.jsx ya hace:
- GET /api/global-categories -> arma el <select> de categorias por tienda
  (campo categories.<source>).
- POST /api/global-search con:
    sources: [solo las tiendas de super seleccionadas]
    <source>_category_id: categoria elegida por tienda
    query / min_price / max_price / scan_scope
  y luego polling a /api/global-search/{job_id} (soporta respuesta directa o
  por job, segun como responda el server del proyecto).

### 4.3 Reglas de UX

1. Modo por categoria: estas fuentes pueden ejecutarse SIN palabra clave. El
   front no obliga a escribir query si hay al menos una categoria seleccionada
   (coincide con has_category del backend).
2. Render de resultados: el item ya trae title, formatted_price,
   price_original, discount_percent, image, url, store. Reutiliza la tarjeta
   de resultados existente del proyecto (ResultCard o equivalente) en lugar de
   la tarjeta minima del componente de referencia, para mantener el estilo.
3. Backend: como /api/global-search ya itera por las sources que recibe en el
   payload, NO requiere cambios extra para soportar la pestana; basta con que
   los RUNNERS de las 7 fuentes esten registrados (puntos 2.4 y 2.5).

--------------------------------------------------------------------------

## 5) Endpoints Walmart/Falabella (Paso 1 - confirmar)

Lider, acuenta y Tottus quedan listos salvo la URL del endpoint JSON de
catalogo. Para activarlos:

- Lider/acuenta: define el template en lider_scraper/lider_stores.py (campo
  api_template) o via variable de entorno LIDER_API_TEMPLATE / ACUENTA_API_TEMPLATE.
  Campos disponibles en el template: {host} {category} {query} {limit} {page}.
- Tottus: define TOTTUS_API_TEMPLATE o API_TEMPLATE_DEFAULT en tottus_scraper/tottus.py.

Como encontrar el endpoint: abre la web del supermercado, navega a una
categoria, abre DevTools -> Network -> filtra por Fetch/XHR y copia la URL que
devuelve el JSON de productos. El parser ya reconoce los nombres de campo mas
comunes; si el endpoint usa otros, ajusta las tuplas _*_KEYS.

Si el sitio bloquea las peticiones directas, replica el fallback con Playwright
que ya usa el scraper de AliExpress.
