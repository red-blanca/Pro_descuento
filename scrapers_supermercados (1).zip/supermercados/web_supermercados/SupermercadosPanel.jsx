// SupermercadosPanel.jsx
// ---------------------------------------------------------------------------
// Pestana / seccion "Supermercados" para la UI del proyecto (React + Vite).
//
// DISENO: vista SEPARADA, funcionalidad UNIFICADA.
//   - Es una pestana propia (al estilo de las del proyecto) dedicada a super.
//   - Por dentro llama EXACTAMENTE al mismo backend que el buscador global
//     (/api/global-search + /api/global-categories), solo que acotado a las
//     7 fuentes de supermercado y en modo "por categoria".
//
// Codex: adapta clases/estilos a los del proyecto y reutiliza la tarjeta de
// resultados existente (p.ej. <ResultCard/>) si ya hay una. Este archivo es
// una referencia funcional completa y autosuficiente.
// ---------------------------------------------------------------------------

import { useEffect, useState } from "react";

// Debe coincidir con registry.SUPERMARKET_SOURCE_IDS / SUPERMARKET_META.
const SUPERMARKET_SOURCES = [
  { id: "jumbo", label: "Jumbo" },
  { id: "santaisabel", label: "Santa Isabel" },
  { id: "unimarc", label: "Unimarc" },
  { id: "alvi", label: "Alvi" },
  { id: "lider", label: "Lider" },
  { id: "acuenta", label: "acuenta" },
  { id: "tottus", label: "Tottus" },
];

const API = ""; // mismo origen; ajusta si el front usa otra base de API

export default function SupermercadosPanel() {
  const [categoriesBySource, setCategoriesBySource] = useState({});
  const [selected, setSelected] = useState(() =>
    Object.fromEntries(SUPERMARKET_SOURCES.map((s) => [s.id, false]))
  );
  const [categoryBySource, setCategoryBySource] = useState({});
  const [query, setQuery] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [results, setResults] = useState([]);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  // Carga el arbol de categorias por tienda (mismo endpoint del proyecto).
  useEffect(() => {
    fetch(`${API}/api/global-categories`)
      .then((r) => r.json())
      .then((data) => setCategoriesBySource(data.categories || data || {}))
      .catch(() => setCategoriesBySource({}));
  }, []);

  const toggleSource = (id) =>
    setSelected((prev) => ({ ...prev, [id]: !prev[id] }));

  const activeSources = SUPERMARKET_SOURCES.filter((s) => selected[s.id]).map(
    (s) => s.id
  );

  const hasCategory = activeSources.some((id) => categoryBySource[id]);
  const canSearch =
    activeSources.length > 0 && (query.trim() !== "" || hasCategory);

  async function runSearch() {
    setError("");
    setStatus("loading");
    setResults([]);

    // Payload identico al del buscador global, pero acotado a supermercados.
    const payload = {
      query: query.trim(),
      sources: activeSources,
      min_price: minPrice ? Number(minPrice) : 0,
      max_price: maxPrice ? Number(maxPrice) : 0,
      scan_scope: "fast",
    };
    for (const id of activeSources) {
      payload[`${id}_category_id`] = categoryBySource[id] || "";
    }

    try {
      const res = await fetch(`${API}/api/global-search`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      // El proyecto usa jobs async: /api/global-search devuelve job_id y se
      // hace polling a /api/global-search/{job_id}. Soportamos ambos casos.
      if (data.job_id) {
        await pollJob(data.job_id);
      } else {
        setResults(flatten(data));
        setStatus("done");
      }
    } catch (e) {
      setError(String(e));
      setStatus("error");
    }
  }

  async function pollJob(jobId) {
    for (let i = 0; i < 60; i++) {
      await new Promise((r) => setTimeout(r, 1500));
      const r = await fetch(`${API}/api/global-search/${jobId}`);
      const d = await r.json();
      if (d.status === "done" || d.status === "completed" || d.results) {
        setResults(flatten(d));
        setStatus("done");
        return;
      }
      if (d.status === "error" || d.status === "failed") {
        setError(d.error || "Error en la busqueda");
        setStatus("error");
        return;
      }
    }
    setStatus("done");
  }

  function flatten(data) {
    // Normaliza distintas formas de respuesta a una lista plana de items.
    if (Array.isArray(data?.results)) return data.results;
    if (Array.isArray(data?.items)) return data.items;
    const out = [];
    const groups = data?.results || data?.sources || {};
    for (const key of Object.keys(groups)) {
      const g = groups[key];
      if (Array.isArray(g)) out.push(...g);
      else if (Array.isArray(g?.items)) out.push(...g.items);
    }
    return out;
  }

  return (
    <section className="supermercados-panel">
      <header>
        <h2>Supermercados</h2>
        <p>Busqueda conjunta por categoria en supermercados de Chile.</p>
      </header>

      <div className="filtros">
        <input
          type="text"
          placeholder="Palabra clave (opcional si eliges categoria)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <input
          type="number"
          placeholder="Precio min"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
        />
        <input
          type="number"
          placeholder="Precio max"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
        />
      </div>

      <div className="tiendas">
        {SUPERMARKET_SOURCES.map((s) => (
          <div key={s.id} className="tienda">
            <label>
              <input
                type="checkbox"
                checked={selected[s.id]}
                onChange={() => toggleSource(s.id)}
              />
              {s.label}
            </label>
            {selected[s.id] && (
              <select
                value={categoryBySource[s.id] || ""}
                onChange={(e) =>
                  setCategoryBySource((prev) => ({
                    ...prev,
                    [s.id]: e.target.value,
                  }))
                }
              >
                <option value="">Todas las categorias</option>
                {(categoriesBySource[s.id] || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            )}
          </div>
        ))}
      </div>

      <button disabled={!canSearch || status === "loading"} onClick={runSearch}>
        {status === "loading" ? "Buscando..." : "Buscar en supermercados"}
      </button>

      {error && <p className="error">{error}</p>}

      <div className="resultados">
        {results.map((item, idx) => (
          <article key={item.id || idx} className="card">
            {item.image && <img src={item.image} alt={item.title} />}
            <h3>{item.title || item.name}</h3>
            <p className="store">{item.store || item.source}</p>
            <p className="precio">{item.formatted_price || item.price}</p>
            {item.discount_percent > 0 && (
              <span className="badge">-{item.discount_percent}%</span>
            )}
            {item.url && (
              <a href={item.url} target="_blank" rel="noreferrer">
                Ver producto
              </a>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}
